## <i><b> Follow Me</b></i> <br>[![Github](https://img.shields.io/badge/Github-AZIM--MAHMUD-dimgray?style=flat-square&logo=github)](https://github.com/Azim-vau)<br> [![Facebook](https://img.shields.io/badge/Facebook-AZIM-blue?style=flat-square&logo=facebook)](https://www.facebook.com/100022097600640)<br> [![Instagram](https://img.shields.io/badge/Instagram-AZIM--MAHMUD-hotpink?style=flat-square&logo=instagram)](https://Instagram.com/azimmahmud143)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-AZIM--MAHMUD-deepgreen?style=flat-square&logo=whatsapp)](https://chat.whatsapp.com/DA8asUGMmRG42yKXrCsVb7)



<h1 align="center">AZIM0.5</h1>
<p align="center">
      A new international facebook account cracker tool for termux users
</p>






## <b>installation</b>
```
$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install bs4
$ pkg install git
$ git clone https://github.com/Azim-vau/Azim0.5.git
$ cd Azim0.5
$ python2 crack.py
```


## <b>Access Token Generator Apk</b><br>
 <a href="https://play.google.com/store/apps/details?id=com.proit.thaison.getaccesstokenfacebook">DOWNLOAD</a>

